/*
 * main.c
 *
 *  Created on: 14 Feb 2013
 *      Author: Maxime Vincent
 * Description: Virtually the most simple demo that can be run on an ARM MCU.
 *              The target is barely running - all clocks are off, the core is
 *              just executing a few simple instructions.
 *
 *     Purpose: Purpose is to demonstrate an openocd-gdb setup to flash and 
 *              step through code on the target.
 *
 *     Context: Written in the context of the Embedded C course by TASS Belgium.
 */

/* Includes */
#include "main.h"
#include <stdint.h>
#include <math.h>

/* Defines */
#define EVER        (;;)

void fast_increment(uint32_t * i);
uint32_t isqrt3(uint32_t n);

/* main C entry point - should never return */
void main(void)
{
    uint32_t i=0;
    uint32_t result;
    float    wortel = 0.0f;

    for EVER
    {
        i++;
        fast_increment(&i);
        result = isqrt3(308025);
        wortel = sqrtf(308025.0f);
    }
}

__attribute__ ((section (".fastcode"))) 
void fast_increment(uint32_t * i)
{
    (*i)++;
}

__attribute__ ((section (".fastcode"))) 
uint32_t isqrt3(uint32_t n)
{
   uint32_t root = 0, bit, trial;
   bit = (n >= 0x10000) ? 1<<30 : 1<<14; /* 16bit or 32 bit? */
   do
   {
      trial = root+bit;
      if (n >= trial)
      {
         n -= trial;
         root = trial+bit;
      }
      root >>= 1;
      bit >>= 2;
   } while (bit);
   return root;
}
